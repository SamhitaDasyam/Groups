
import { Component, OnInit } from "@angular/core";
import { IGrequests } from "../../api/groupsAdmin/grequests";
import { GRequestsService } from "../../api/groupsAdmin/grouprequests.service";



@Component({
    selector:'pm-group',
     templateUrl:'./grouprequest.component.html',
    styles:['thead{color:#337AB7;}']
     
 })
 export class GroupRequestComponent implements OnInit{
     pageTitle:string='Group Members';
     groupMembers:IGrequests[]=[];
     _listFilter:string;
    
     errorMessage:string;
     constructor(private _gRequestService:GRequestsService)
     {
          
     }
    
 
  ngOnInit():void{
      // console.log('In OnInit')
      this._gRequestService.getGroupMembers().subscribe(groupMembers=> {
          this.groupMembers=groupMembers;
        
         
          
      },
      error=>this.errorMessage=<any>error
      );
     
      
  }
  deleteGroupMember(groupId:number,userId:number):void{
    this._gRequestService.deleteGroupMember(groupId,userId).subscribe(groupMembers=>console.log(groupMembers))
  }
 

}
 

 