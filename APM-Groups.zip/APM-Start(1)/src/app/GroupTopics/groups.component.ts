
import { Component, OnInit } from "@angular/core";
import { GroupsService } from "../../api/groups/groups.service";
import { ITopic } from '../../api/topics/topics';
import { TopicService } from '../../api/topics/topics.service';
import { GroupsServiceAdmin } from "../../api/groupsAdmin/groups.service";
import { IGroups } from "../../api/groupsAdmin/groups";


@Component({
  selector:'pm-topic',
  templateUrl: './groups.component.html',
  styles: ['thead{color:#337AB7;}']

})
export class GroupComponentAdmin implements OnInit {
  pageTitle: string = 'groups';
  groups: IGroups[] = [];
  topic: ITopic[] = [];
  errorMessage: string;
  constructor(private _groupService: GroupsServiceAdmin, topicService: TopicService) {

  }


  ngOnInit(): void {
    // console.log('In OnInit')
    this._groupService.getGroups().subscribe(groups => {
      this.groups = groups;
      // this.filteredCustomers=this.customers;


    },
      error => this.errorMessage = <any>error
    );


  }
  private showTopics(groups: IGroups) {

    GroupsServiceAdmin.group = groups;



  }
  private showMembers(groups: IGroups) {

    GroupsServiceAdmin.group = groups;



  }
  private showRequests(groups: IGroups) {

    GroupsServiceAdmin.group = groups;



  }



}


