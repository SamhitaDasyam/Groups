export class Groups {
    groupId: number;
    groupName: string;
    groupAdmin: string;
    description: string;
}