export interface IGrequests{
    g_requestId:number;
    groupId:number;
    
    userId:number;
    status:string;
    userName:string;
   
   
}