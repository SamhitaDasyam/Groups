export interface IGroups{
    groupId:number;
    description:string;
    groupAdmin:string;
    groupName:string;

   
}