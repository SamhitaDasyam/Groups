export interface ITopic{
    topic_id:number;
    topic_started_by:number;
    topic_desc:string;
    
    group_id:number;
     

   
}