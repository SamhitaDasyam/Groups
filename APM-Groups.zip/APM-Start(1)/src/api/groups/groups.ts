export class IGroup{
  groupId:number;
  groupName:string;
groupAdmin:number;
description:string;
}
export class IPostT{
topic_desc:string;
topicId:number;
topic_started_by:string;
groupId:number;

}
export class IGroup1{
 
groupAdmin:number;
groupName:string;

}

export class IGroup2{
groupName:string;
userId:number;
}

export class User{
  userId:number;
  userName:string;
}