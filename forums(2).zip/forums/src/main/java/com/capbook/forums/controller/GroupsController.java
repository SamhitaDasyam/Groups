package com.capbook.forums.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capbook.forums.dao.IGroupCommentDao;
import com.capbook.forums.dao.IGroupsDao;
import com.capbook.forums.dao.IRequestDao;
import com.capbook.forums.model.FriendsList;
import com.capbook.forums.model.Group_Comments;
import com.capbook.forums.model.Group_Request;
import com.capbook.forums.model.Group_Topic;
import com.capbook.forums.model.Groups;
import com.capbook.forums.model.UserProfile;
import com.capbook.forums.service.IGroupNameService;
import com.capbook.forums.service.IGroupsService;
import com.capbook.forums.service.IRequestService;
import com.capbook.forums.service.IUserService;

@RestController
@CrossOrigin("http://localhost:4200")
public class GroupsController {

	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IGroupsService groupService;
	@Autowired
	private IRequestService requestService;

	@Autowired
	private IGroupNameService groupNameService;
	
	@Autowired
	private IGroupsDao groupsDao;
	@Autowired
	private IGroupCommentDao commentDao;
	@Autowired
	private IRequestDao requestDao;
	
	@GetMapping("/groupadmin/{input}")
	public ResponseEntity<List<Groups>> findGroups(@PathVariable("input") Integer input){
		
		List<Groups> groupname=groupsDao.findGroups(input);
		
		if(groupname.isEmpty()) {
			
			return new ResponseEntity("No Groups available",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Groups>>(groupname,HttpStatus.OK);
		
	}
	
	@GetMapping("/groups/{input}")
	public ResponseEntity<List<Groups>> findGroupsuser(@PathVariable("input") Integer input){
		
		List<Groups> groupsname=groupsDao.findGroupsuser(input);
		
		if(groupsname.isEmpty()) {
			
			return new ResponseEntity("No Groups available",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Groups>>(groupsname,HttpStatus.OK);
		
	}
	@GetMapping("/groups/findUser/{input}")
	public ResponseEntity<UserProfile> findUserName(@PathVariable("input") Integer input){
		
		UserProfile groupsname=userService.findGroupsuser(input);
		
		if(groupsname==null) {
			
			return new ResponseEntity("No Groups available",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<UserProfile>(groupsname,HttpStatus.OK);
		
	}
	
	@GetMapping("/findall/{groupId}")
	public ResponseEntity<List<FriendsList>> findFriends(@PathVariable("groupId")Integer groupId){
		//List<FriendsList> friendsList=groupService.findFriends(groupId);
		List<FriendsList> friendsList = null;
		return new ResponseEntity<List<FriendsList>>(friendsList, HttpStatus.OK);
	}
	
	@PostMapping("/creategroup")
	public ResponseEntity<Groups> createGroup(@RequestBody Groups groups){
		Groups group=groupService.createGroup(groups);
		
		System.out.println("*******************"+group);
		return new ResponseEntity<Groups>(group, HttpStatus.OK);
		
	}
	@PostMapping("/comment")
	public ResponseEntity<List<Group_Comments>> postComment(@RequestBody Group_Comments group_Comments){
		List<Group_Comments> grouptopics=groupService.postComment(group_Comments);
		
		System.out.println("*******************"+grouptopics);
		return new ResponseEntity<List<Group_Comments>>(grouptopics, HttpStatus.OK);
		
	}
	@PostMapping("/postT")
	public ResponseEntity<List<Group_Topic>> postT(@RequestBody Group_Topic topic){
		List<Group_Topic> postTList=groupService.post(topic);
		return new ResponseEntity<List<Group_Topic>>(postTList,HttpStatus.OK);
	}
	
	
	@DeleteMapping("/exitUser/{id}")
	public ResponseEntity<List<FriendsList>> exitFriends(@PathVariable("id")Integer id){
		List<FriendsList> friends= groupService.exitFriends(id);
		if(friends.isEmpty() || friends==null) {
			return new ResponseEntity("Sorry! UserId not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<FriendsList>>(friends, HttpStatus.OK);
		
	}
	
@GetMapping("/requestfind")
	public ResponseEntity<List<Group_Request>> findRequest(){
		List<Group_Request> requestList=requestService.findRequest();
		return new ResponseEntity<List<Group_Request>>(requestList, HttpStatus.OK);
	}
	
	
	@PostMapping("/request")
	public ResponseEntity<List<Group_Request>> requestJoin(
			@RequestBody Group_Request request){
		System.out.println(request);
				List<Group_Request> requests=requestService.requestSent(request);
				if(requests.isEmpty()) {
					return new ResponseEntity("Sorry! request not available!", 
							HttpStatus.NOT_FOUND);
				}
				return new ResponseEntity<List<Group_Request>>(requests, HttpStatus.OK);
	
	
}
	@GetMapping("/getComments/{topicId}")
	public ResponseEntity<List<Group_Comments>> getCommentsForTopic(@PathVariable("topicId") Group_Topic topicId){
		List<Group_Comments> commentsList = commentDao.getGroupComments(topicId);
		if(commentsList.isEmpty()) {
			return new ResponseEntity("Sorry no comments for this topic", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Group_Comments>>(commentsList, HttpStatus.OK);
		
	}
	
	
}
