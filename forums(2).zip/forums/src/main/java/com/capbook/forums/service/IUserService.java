package com.capbook.forums.service;

import java.util.List;

import com.capbook.forums.model.Groups;
import com.capbook.forums.model.UserProfile;

public interface IUserService {

	UserProfile findGroupsuser(Integer input);

	

}
