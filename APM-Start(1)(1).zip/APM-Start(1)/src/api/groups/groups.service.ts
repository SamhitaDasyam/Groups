import { Injectable } from "@angular/core";
import { IFriend } from "./friends";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { IGroup, IPostT, IGroup2, IGroup1, User } from "./groups";
import { Subject } from "../../../node_modules/rxjs/Subject";
import { BehaviorSubject } from 'rxjs';
import { group } from "../../../node_modules/@angular/core/src/animation/dsl";
import { getTypeNameForDebugging } from "../../../node_modules/@angular/core/src/change_detection/differs/iterable_differs";
import { GroupTopic } from "../group-profile/friends";

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class GroupsService{
    private _friendUrl='http://localhost:8083/groups';
    _Url:string='http://localhost:8083/groups';
/*     private friend:IFriend;
 */    private getAllFriends:string='findall';
 public static gName:string;
 //public static gId:number;
 private subject = new Subject<any>();
 /* sendMessage(gName){
     this.subject.next({text:gName}); }
     clearMessage(){
         this.subject.next();
     }
     getMessage():Observable<any>{
         return this.subject.asObservable();

     } */
   
     
   
    constructor(private _http:HttpClient){

    }
    
 

    getFriends():Observable<IFriend[]>{
        this._friendUrl =this._Url+ '/'+this.getAllFriends;
        return  this._http.get<IFriend[]>(this._friendUrl)
 
    }
    createGroup(group:IGroup):Observable<IGroup>
    {
       
       
    // GroupsService.gId=group.groupId;
    
        this._friendUrl =this._Url+ '/'+'creategroup';
       // groupList:IGroup[] =this._http.post<IGroup[]>(this._friendUrl,group);
        return  this._http.post<IGroup>(this._friendUrl,group)

        
    }
    postT(postT:IPostT):Observable<IPostT[]>
    {
     
  
    
        this._friendUrl =this._Url+ '/'+'postT';
        return  this._http.post<IPostT[]>(this._friendUrl,postT)
    }
    getUserDetails(userId:number):Observable<User>
    {
this._friendUrl=this._Url+'/groups/findUser/'+userId;
return this._http.get<User>(this._friendUrl)
    }
    /* deleteCustomers(customerId:number):Observable<ICustomer[]>
    {
        this._Url=this._productUrl+'/'+customerId
        return this._http.delete<ICustomer[]>(this._Url)
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    createCustomers(customer:ICustomer):Observable<ICustomer[]>
    {
        console.log(customer);
        return  this._http.post<ICustomer[]>(this._productUrl,customer)
    }
    getcustomer(customerId:number):Observable<ICustomer[]>{
        this._Url=this._productUrl+'/'+customerId
        //this.customer=this._http.get<ICustomer[]>(this._Url)
        return  this._http.get<ICustomer[]>(this._Url)
        
       
    }
    editCustomers(customer:ICustomer):Observable<ICustomer[]>
    {
       
        return this._http.put<ICustomer[]>(this._productUrl,customer,{})
    } */
    getGroups(groupAdmin:number){

        this._friendUrl=this._Url+'/'+'groupadmin'+'/'+groupAdmin;
        return this._http.get<IGroup1[]>(this._friendUrl)

}
getJoinedGroups(userId:number){
    this._friendUrl=this._Url+'/'+'groups'+'/'+userId;
    return this._http.get<IGroup2[]>(this._friendUrl)

}
}