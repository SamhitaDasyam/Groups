import { Component, OnInit } from '@angular/core';

@Component({
 selector: 'app-homegroup',
  templateUrl: './homegroup.component.html',
  styleUrls: ['./homegroup.component.css']
})
export class HomegroupComponent implements OnInit {
 
  public pageTitle: string='home';


  constructor() { }

  ngOnInit() {
  }

}
