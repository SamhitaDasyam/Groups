package com.capbook.forums.service;

import org.springframework.stereotype.Service;

@Service("groupNameService")
public class GroupNameService implements IGroupNameService{

}
