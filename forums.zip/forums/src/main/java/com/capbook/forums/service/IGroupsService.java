package com.capbook.forums.service;

import java.util.List;

import com.capbook.forums.model.FriendsList;
import com.capbook.forums.model.Group_Comments;
import com.capbook.forums.model.Group_Topic;
import com.capbook.forums.model.Groups;


public interface IGroupsService {

	//List<FriendsList> findFriends(Integer groupId);

Groups createGroup(Groups groups);

	List<Group_Topic> post(Group_Topic topic);

	List<FriendsList> exitFriends(Integer id);

	List<Group_Comments> postComment(Group_Comments group_Topic);
	

}
