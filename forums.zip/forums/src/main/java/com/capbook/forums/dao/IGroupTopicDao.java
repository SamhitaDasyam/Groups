package com.capbook.forums.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.Group_Topic;

@Repository("groupTopicDao")
@Transactional
public interface IGroupTopicDao extends JpaRepository<Group_Topic, Integer>{
	@Query("from Group_Topic t where t.group_id=:groupId")
	List<Group_Topic> findGroupTopics(@Param("groupId")Integer groupId);

}
