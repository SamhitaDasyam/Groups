import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product/product-list.component';
import { ConvertToSpacesPipe } from './shared/convert-t0-spaces.pipe';
import { StarComponent } from './shared/star.component';

import {  HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './products/product-detail.component';
//import { TestComponent } from './test.component';
import {RouterModule} from '@angular/router'
import { WelcomeComponent } from './home/welcome.component';
import { CustomerComponent } from './customer/customer.compomnent';
import { RegistrationComponent } from './registration/registration component';
import { GroupProfileComponent } from './group-profile/group-profile.component';
import { HomegroupComponent } from './homegroup/homegroup.component';
import { GroupComponent } from './group/group.component';
import { DiscoverComponent } from './discover/discover.component';
import { GroupshomeComponent } from './groupshome/groupshome.component';
import { GroupsService } from '../api/groups/groups.service';
import { GroupProfileService } from '../api/group-profile/group-profile.service';
import { GrouphomepageComponent } from './grouphomepage/grouphomepage.component';








@NgModule({
  declarations: [
  //TestComponent,AppComponent
 AppComponent,ProductListComponent,ConvertToSpacesPipe,StarComponent,CustomerComponent, WelcomeComponent ,ProductDetailComponent,
 RegistrationComponent,
 GroupProfileComponent,GroupProfileComponent,HomegroupComponent,GroupComponent,DiscoverComponent, GroupshomeComponent,GrouphomepageComponent
 //MovieComponent
 
  ],
  
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    RouterModule.forRoot([//{path:'products',component:ProductListComponent},
   //{path :'products/:id' ,component:ProductDetailComponent},
 
  /* {path : '',component:HomegroupComponent}, */
  { path: 'groupshome', component: GroupshomeComponent },
  { path: 'discover', component: DiscoverComponent },
  { path: 'create', component: GroupComponent },
  { path: 'groupProfile', component: GroupProfileComponent},
  { path: 'groupHomeProfile', component:GrouphomepageComponent}
])

  ],
  
  providers: [GroupsService,GroupProfileService],
 // bootstrap: [MovieComponent]
  bootstrap: [AppComponent]
})
export class AppModule { }
