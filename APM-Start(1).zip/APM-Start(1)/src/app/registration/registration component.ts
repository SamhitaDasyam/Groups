import { Component, OnInit } from "@angular/core";
import { ICustomer } from "../../api/customer/customer";
import { CustomerService } from "../../api/customer/customer.service";

@Component({
    selector:'reg-form',
    templateUrl:'./registration.component.html'
})
export class RegistrationComponent implements OnInit{
      butlabel:string='Register'
      flag:boolean=false
    customer:ICustomer={
        "customerId": 0,
        "firstName": "",
        "lastName": "",
        "dateOfBirth": null,
        "emailId": "",
        "mobile": "",
        "customerPwd": ""
    }
    constructor(private _customerService:CustomerService)
    {
       
    }
    toggle(customer:ICustomer):void{
        if(this.flag)
        {
            this._customerService.editCustomers(customer).subscribe(customers=>console.log(customers))
        }
        else
        {
            this._customerService.createCustomers(customer).subscribe(customers=>console.log(customers))
        }
    }
   /*  createCustomers(customer:ICustomer):void{
         this.butlabel='Register'
        this._customerService.createCustomers(customer).subscribe(customers=>console.log(customers))
    } */
    ngOnInit():void{
        //this.createCustomers(this.customer)
    }


}