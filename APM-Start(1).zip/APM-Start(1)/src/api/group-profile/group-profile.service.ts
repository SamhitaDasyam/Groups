import { Injectable } from "@angular/core";
import { IFriends, group_request, GroupTopic, GroupComments } from "./friends";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { IGroup } from "../groups/groups";

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class GroupProfileService{
    private _friendUrl='http://localhost:8083/groups';
    _Url:string='http://localhost:8083/groups';
/*     private friend:IFriend;
 */    private getAllFriends:string='findall';

 private groupRequest:group_request;
    private exitGroup:string='exitUser';
    constructor(private _http:HttpClient){

    }
    getFriends(groupId:number):Observable<IFriends[]>{
        this._friendUrl =this._Url+ '/'+this.getAllFriends+'/'+groupId;
        return  this._http.get<IFriends[]>(this._friendUrl)
 
    }
    deleteFriends(userId:number){

        this._friendUrl=this._Url+'/'+this.exitGroup+'/'+userId;
        return this._http.delete<IFriends[]>(this._friendUrl)
    }
    addFriends(addRequest:group_request):Observable<group_request[]>{
        this._friendUrl=this._Url+'/'+'request';
        return this._http.post<group_request[]>(this._friendUrl,addRequest);
    }
    postComment(groupComment:GroupComments):Observable<GroupComments[]>{
        this._friendUrl=this._Url+'/'+'comment';
        return this._http.post<GroupComments[]>(this._friendUrl,groupComment);
    }
    }

    
