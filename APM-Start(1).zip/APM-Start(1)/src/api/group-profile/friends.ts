export interface IFriends{
    id:number;
    friendName:string

   
}
export class group_request{
    
  g_requestId:number;
	groupId:number;
	userId:number;
	status:string;    

}
export class GroupComments {
  groupCommentId:number;
  topicId:GroupTopic;
  commentText:string;
  postedDate:Date;
  commented_by:string;

}
export class GroupTopic{
  topic_id:number;
  group_id:number;
  topic_desc:string;
  topic_started_by:number;
}