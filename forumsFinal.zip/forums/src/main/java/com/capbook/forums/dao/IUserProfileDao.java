package com.capbook.forums.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.UserProfile;


@Repository("userProfileDao")
@Transactional
public interface IUserProfileDao extends JpaRepository<UserProfile, Integer>{
	
	UserProfile findByUserId(Integer input);
	
	@Query("select u.userName from UserProfile u where u.userId=:userId")
	String getUserName(@Param("userId") Integer userId);

}
