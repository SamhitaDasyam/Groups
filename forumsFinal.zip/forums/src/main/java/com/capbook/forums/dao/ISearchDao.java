package com.capbook.forums.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.Groups;


@Transactional
@Repository("searchDao")
public interface ISearchDao extends JpaRepository<Groups,Integer> {
	
	@Query("select g.groupName from Groups g where g.groupName like :letter%")
	public List<String> getGroupNames(@Param("letter") String letter) ;
	
	/*@Query("select groupName from Groups")
	public List<String> getAllGroupNames();*/
	
	

}
