package com.capbook.forums.service;

import java.util.List;

import com.capbook.forums.model.Group_Request;
import com.capbook.forums.model.Group_Topic;
import com.capbook.forums.model.Groups;



public interface IGroupService {

	List<Groups> getAllGroups(Integer userId);

	List<Group_Topic> getAllTopics(Integer groupId);

	List<Group_Topic> deleteTopic(Integer groupId, Integer topicId);

	List<Group_Request> getAllGroupMembers(Integer groupId);

	List<Group_Request> deleteGroupMember(Integer groupId, Integer userId);

	List<Group_Request> getAllGroupRequests(Integer groupId);

	List<Group_Request> updateStatus(Group_Request approve);
	
	
	

}
