package com.capbook.forums.service;

import java.util.List;

import com.capbook.forums.model.Groups;
import com.capbook.forums.model.UserProfile;



public interface ISearchService {
	
	public List<String> getGroupNames(String letter);

	public List<String> getUserName(String username);

	public List<Groups> getAllGroupNames();

	public List<UserProfile> getAllUserNames();

}
