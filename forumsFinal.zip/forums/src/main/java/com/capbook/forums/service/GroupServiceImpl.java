package com.capbook.forums.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capbook.forums.dao.IGroupRequestDao;
import com.capbook.forums.dao.IGroupTopicDao;
import com.capbook.forums.dao.IGroupsDao;
import com.capbook.forums.dao.IUserProfileDao;
import com.capbook.forums.model.Group_Request;
import com.capbook.forums.model.Group_Topic;
import com.capbook.forums.model.Groups;




@Service
public class GroupServiceImpl implements IGroupService{
	
	@Autowired
	private IGroupsDao groupsDao;
	
	@Autowired
	private IGroupTopicDao groupTopicDao;
	
	@Autowired
	private IGroupRequestDao groupRequestDao;
	

	@Autowired
	private IUserProfileDao userDao;
	
	@Override
	public List<Groups> getAllGroups(Integer userId) {
		
		//String groupAdmin=groupsDao.getGroupAdmin(userId);
		
		return groupsDao.getAllGroups(userId);
	}


	@Override
	public List<Group_Topic> getAllTopics(Integer groupId) {
		return groupTopicDao.getAllTopics(groupId);
		
	}


	@Override
	public List<Group_Topic> deleteTopic(Integer groupId, Integer topicId) {
		System.out.println("in delete service");
		groupTopicDao.deleteById(topicId);
		return groupTopicDao.getAllTopics(groupId);
	}


	@Override
	public List<Group_Request> getAllGroupMembers(Integer groupId) {
		List<Group_Request> members=groupRequestDao.getAllGroupMembers(groupId);
		for(Group_Request member:members) {
			System.out.println("for each loop");
			member.setUserName(userDao.getUserName(member.getUserId()));
			
		}
		
		return members ;
	}


	@Override
	public List<Group_Request> deleteGroupMember(Integer groupId, Integer userId) {
		 List<Group_Request>groups=groupRequestDao.deleteGroupMember(groupId, userId);

		 for( Group_Request group: groups)
		 {
			 groupRequestDao.delete(group);
			 
		 }
		 
		 return groupRequestDao.getAllGroupMembers(groupId);
	}


	@Override
	public List<Group_Request> getAllGroupRequests(Integer groupId) {
		List<Group_Request> approve=groupRequestDao.getAllGroupRequests(groupId);
		for(Group_Request app:approve) {
			System.out.println("for each loop");
			app.setUserName(userDao.getUserName(app.getUserId()));
			System.out.println(app);
		}
		
		return approve ;
		
	}


	@Override
	public List<Group_Request> updateStatus(Group_Request approve) {
		
//		groupRequestDao.updateStatus(approve.getG_requestId());
//		return groupRequestDao.getAllGroupRequests(approve.getGroupId());
		groupRequestDao.save(approve);
		return groupRequestDao.findAll();
	}

}
