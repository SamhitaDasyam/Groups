package com.capbook.forums.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capbook.forums.dao.IRequestDao;
import com.capbook.forums.model.Group_Request;

@Service("requestService")
public class RequestService implements IRequestService{

	@Autowired
	private IRequestDao requestDao;
	
	
	@Override
	public List<Group_Request> requestSent(Group_Request request) {

		requestDao.save(request);
		return requestDao.findAll();
	}

	@Override
	public List<Group_Request> findRequest() {
		List<Group_Request> list =requestDao.findAll();
		return list;
	}

	@Override
	public List<Group_Request> getRequestIdAndDelete(Integer userId) {
		Integer groupReqId = requestDao.getRequestId(userId);
		requestDao.deleteById(groupReqId);
		return requestDao.findAll();
	}

}
